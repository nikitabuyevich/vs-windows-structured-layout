#ifndef BAR_FOO_H
#define BAR_FOO_H

// TODO: If you wish to change DLL_EXPORTS
// to something else, make sure you update the
// Preprocessor Definitions (Under C/C++ >> Preprocessor)
#ifdef DLL_EXPORTS
#define DLL_API __declspec(dllexport)
#else
#define DLL_API __declspec(dllimport)
#endif


// Some shared library
namespace bar
{
	// Some public function
	DLL_API void Foo();
}


#endif //BAR_FOO_H
