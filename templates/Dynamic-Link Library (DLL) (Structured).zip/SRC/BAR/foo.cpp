#include "pch/pch.h"
#include "bar/foo.h"
#include <iostream>

void bar::Foo()
{
	std::cout << "Hello from bar::Foo!\n";
}
