#ifndef FOO_BAR_H
#define FOO_BAR_H

// Some static library
namespace foo
{
	// Some public function
	void Bar();
}


#endif //FOO_BAR_H
