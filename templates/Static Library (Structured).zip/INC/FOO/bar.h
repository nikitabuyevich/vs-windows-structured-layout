#ifndef FOO_BAR_H_
#define FOO_BAR_H_

// Some static library
namespace foo
{
	// Some public function
	void Bar();
}


#endif //FOO_BAR_H_

