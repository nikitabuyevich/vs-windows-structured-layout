#include "pch/pch.h"
#include "foo/bar.h"
#include <iostream>

void foo::Bar()
{
	std::cout << "Hello from foo::Bar!\n";
}
